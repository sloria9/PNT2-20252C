var x = 17



//const object = {}

//console.log(object, typeof object)

const explicito = String(x) //Declaracion Explicita de tipo

console.log(x, typeof x)
console.log(explicito, typeof explicito)


console.log(x == explicito)
console.log(x === explicito)

const implicita = x + ""

console.log(implicita, typeof implicita)


let invalido

console.log("valor invalido", invalido)



function imprimirUno(){
  console.log("Uno")
}

function imprimirDos(){
  console.log("Dos")
}

function imprimirTres(){
  console.log("Tres")
}


setTimeout(imprimirUno, 5000)
setTimeout(imprimirDos)
setTimeout(imprimirTres)

console.log("Hola mundo... Yo me tengo que ejecutar de primer")
const EDAD_MINIMA = 18;

const personas = [
  {
    firstName: 'Matias',
    lastName: 'Leonel',
    age: 20,
  },
  {
    firstName: 'Roberto',
    lastName: 'Levy',
    age: 17,
  },
  {
    firstName: 'Lucas',
    lastName: 'Rodriguez',
    age: 18,
  },
  {
    firstName: 'Pablo',
    lastName: 'Agis',
    age: 12,
  },
  {
    firstName: 'Sofia',
    lastName: 'Loria',
    age: 24,
  },
  {
    firstName: 'Maria',
    lastName: 'Lamas',
    age: 27,
  },
];

export { personas, EDAD_MINIMA };

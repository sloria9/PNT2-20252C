import { personas } from './personas';

//Referencia: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter

/**
 * CONSIGNA:realizar una funcion que dado un array de objetos persona devuelva
 * un nuevo array solamente con las personas que puedan entrar al casino
 *
 * [
 *  {
 *    firstName,
 *    lastName,
 *    age
 *  },
 *  ...,
 *  n
 * ]
 */

function isAdult(persona) {
  // persona es un objeto con la forma { firstName, lastName, age }
  return persona.age >= 18;
}

function validateAgeForCasino(personas) {
  // Filtramos el array original
  const personasQuePuedenEntrar = personas.filter(isAdult);
  return personasQuePuedenEntrar;
}

const puedenEntrar = validateAgeForCasino(personas);
console.log(puedenEntrar);
